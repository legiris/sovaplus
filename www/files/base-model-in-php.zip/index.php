<?php
require_once 'BaseManager.php'; //zalezi na poradi
require_once 'Author.php';

//inicializace
$author = new Author();

if (isset($_POST['action']) && $_POST['action'] == 'Uložit') {	
	if (isset($_GET['id'])) { 
		$author->find($_GET['id']);
	}
	$author->setFormData($_POST);
	$author->save();
	header('Location: index.php');
} elseif (isset($_GET['action']) && $_GET['action'] == 'delete') {
	$author->find($_GET['id']);
	$author->delete();
	header('Location: index.php');
} elseif (isset($_GET['id'])) {
	$author->find($_GET['id']);
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="description" content="" />
		
		<title>OOP: navrhujeme jednoduchý model</title>
		
		<link rel="shortcut icon" href="/favicon.ico" />
		
	</head>	
	<body>
		<h2>Přidat nebo upravit data</h2>	
		
		<form method="POST">
		<table>
			<tr><td>Jméno:</td><td><input type="text" name="name" value="<?php if (isset($_GET['id'])) { echo $author->getName(); } ?>" /></td></tr>
			<tr><td>Příjmení:</td><td><input type="text" name="surname" value="<?php if (isset($_GET['id'])) { echo $author->getSurname(); } ?>" /></td></tr>
			<tr><td>Narození:</td><td><input type="text" name="birth" value="<?php if (isset($_GET['id'])) { echo $author->getBirth(); } ?>" />&nbsp;(yyyy-mm-dd)</td></tr>
			<tr><td>Úmrtí:</td><td><input type="text" name="death" value="<?php if (isset($_GET['id'])) { echo $author->getDeath(); } ?>" />&nbsp;(yyyy-mm-dd)</td></tr>
			<tr><td>Stát:</td><td><input type="text" name="country" value="<?php if (isset($_GET['id'])) { echo $author->getCountry(); } ?>" /></td></tr>
			<tr><td></td><td><input type="submit" value="Uložit" name="action" /></td></tr>
		</table>
		</form>
		
		<hr />
		
		<h2>Seznam autorů</h2>
		
		<table>
			<tr><th>Id</th><th>Jméno</th><th>Příjmení</th><th>Narození</th><th>Úmrtí</th><th>Stát</th><th></th><th></th></tr>
		<?php
		$authors = $author->fetchAll();
		
		foreach ($authors as $author) {			
			echo '<tr><td>' . $author->id . '</td><td>' . $author->name . '</td><td>' . $author->surname . '</td><td>'
							. $author->birth . '</td><td>' . $author->death . '</td><td>' . $author->country . '</td>
				<td><a href="index.php?id=' . $author->id . '" title="Upravit">Upravit</a>&nbsp;&nbsp;
					<a href="index.php?id=' . $author->id . '&action=delete" title="Smazat">Smazat</a></td></tr>';
		}
		?>
		</table>
		
	</body>
</html>