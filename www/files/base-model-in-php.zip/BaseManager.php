<?php

/**
 * Description of BaseManager
 *
 * @author Admin
 */
abstract class BaseManager
{
	/**
	 * @var PDO
	 */
	protected $db;
	
	
	public function __construct()
	{
		if (!$this->db) {
			$this->db = new PDO('mysql:host=localhost;dbname=oop', 'root', '');
			$this->db->exec('SET CHARACTER SET utf8');
		}
		return $this->db;
	}
	
}
