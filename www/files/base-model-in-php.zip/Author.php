<?php

/**
 * Description of Author
 *
 * @author Admin
 */
class Author extends BaseManager
{
	/**
	 * @var int
	 */
	protected $id;
	
	/**
	 * @var string
	 */
	protected $name;
	
	/**
	 * @var string
	 */
	protected $surname;
	
	/**
	 * @var date
	 */
	protected $birth;
	
	/**
	 * @var date
	 */
	protected $death;
	
	/**
	 * @var string
	 */
	protected $country;

	
	/**
	 * @return int
	 */
	public function getId()
	{
		return $this->id;
	}
	
	/**
	 * @param int $id
	 */
	public function setId($id)
	{
		$this->id = $id;
	}

	/**
	 * @return string
	 */
	public function getName()
	{
		return $this->name;
	}
	
	/**
	 * @param string $name
	 */
	public function setName($name)
	{
		$this->name = $name;
	}
	
	/**
	 * @return string
	 */
	public function getSurname()
	{
		return $this->surname;
	}
	
	/**
	 * @param string $surname
	 */
	public function setSurname($surname)
	{
		$this->surname = $surname;
	}
	
	/**
	 * @return date
	 */
	public function getBirth()
	{
		return $this->birth;
	}
	
	/**
	 * @param date $birth
	 */
	public function setBirth($birth)
	{
		$this->birth = $birth;
	}
	
	/**
	 * @return date
	 */
	public function getDeath()
	{
		return $this->death;
	}
	
	/**
	 * @param date $death
	 */
	public function setDeath($death)
	{
		$this->death = $death;
	}
	
	/**
	 * @return date
	 */
	public function getCountry()
	{
		return $this->country;
	}
	
	/**
	 * @param string $country
	 */
	public function setCountry($country)
	{
		$this->country = $country;
	}
	
	
	/**
	 * nastavi data
	 * @param array $data
	 */
	public function setFormData($data)
	{
		$this->setName($data['name']);
		$this->setSurname($data['surname']);
		$this->setBirth($data['birth']);
		$this->setDeath($data['death']);
		$this->setCountry($data['country']);
	}


	
	/**
	 * funkce vrati vsechny zaznamy z DB
	 * @return array
	 */
	public function fetchAll()
	{
		//statement handle
		$sth = $this->db->query('
			SELECT
				id, name, surname, birth, death, country
			FROM
				author
			');
		
		$authors = $sth->fetchAll(PDO::FETCH_CLASS);
		
		return $authors;
	}
	
	/**
	 * funkce ulozi data
	 */
	public function save()
	{
		if ($this->id == NULL) {
			$sth = $this->db->prepare('
				INSERT INTO
					author (name, surname, birth, death, country)
				VALUES 
					(:name, :surname, :birth, :death, :country)
				');
			$sth->execute(array(
				':name'		=> $this->getName(),
				':surname'	=> $this->getSurname(),
				':birth'	=> $this->getBirth(),
				':death'	=> $this->getDeath(),
				':country'	=> $this->getCountry()
			));
		} else {
			$sth = $this->db->prepare('
				UPDATE
					author 
				SET 
					name = :name,
					surname = :surname,
					birth = :birth,
					death = :death,
					country = :country
				WHERE
					id = :id
				');
			$sth->execute(array(
				':id'		=> $this->getId(),
				':name'		=> $this->getName(),
				':surname'	=> $this->getSurname(),
				':birth'	=> $this->getBirth(),
				':death'	=> $this->getDeath(),
				':country'	=> $this->getCountry()
			));
		}
	}
	
	
	/**
	 * nacteni dat o objektu
	 * @param int $id
	 */
	public function find($id)
	{
		$sth = $this->db->prepare('
			SELECT
				id, name, surname, birth, death, country
			FROM
				author
			WHERE
				id = :id
			');
		$sth->execute(array(
			':id' => $id
		));
		
		$author = $sth->fetch(PDO::FETCH_ASSOC);
		
		$this->setId($author['id']);
		$this->setName($author['name']);
		$this->setSurname($author['surname']);
		$this->setBirth($author['birth']);
		$this->setDeath($author['death']);
		$this->setCountry($author['country']);
	}

	/**
	 * odstraneni zaznamu z DB
	 */
	public function delete()
	{
		$sth = $this->db->prepare('
			DELETE FROM
				author
			WHERE
				id = :id
			');
		$sth->execute(array(
			':id' => $this->getId()
		));
	}
	
}
